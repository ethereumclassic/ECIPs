---
ecip: <ECIP number>
title: <ECIP title>
author: <list of authors' real names and optionally, email addrs>
discussions-to: <email address>
status: <Draft | Active | Accepted | Deferred | Rejected | Withdrawn | Final | Superseded>
type: <Standards Track | Informational | Process>
created: <date created on, in ISO 8601 (yyyy-mm-dd) format>
replaces: <ECIP number>
superseded-by: <ECIP number>
resolution: <url>
---

### Abstract

### Motivation

### Specification

### Rationale

### Implementation

